/**
 * 첫 번째 Java 프로그램
 * Hello World를 출력하는 간단한 예제
 */
public class HelloWorld {
    /**
     * 프로그램의 시작점
     * @param args 명령줄 인자 배열
     */
    public static void main(String[] args) {
        // 콘솔에 "Hello, World!" 출력
        System.out.println("Hello, World!");
    }
}

