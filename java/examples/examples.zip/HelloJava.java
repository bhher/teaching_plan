/**
 * 한글 메시지를 출력하는 예제
 */
public class HelloJava {
    public static void main(String[] args) {
        System.out.println("안녕하세요, Java!");
        System.out.println("Java 프로그래밍을 시작합니다.");
    }
}

