/**
 * 변수를 사용하여 이름을 출력하는 예제
 */
public class HelloName {
    public static void main(String[] args) {
        // 문자열 변수 선언 및 초기화
        String name = "홍길동";
        
        // 변수를 사용하여 메시지 출력
        System.out.println("안녕하세요, " + name + "님!");
        System.out.println("Java 학습을 환영합니다.");
    }
}

