$(function(){
  var slider = $('.slick-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    speed: 500,
    arrows: false,
    dots: false,
    pauseOnHover: true,
    infinite: true,
    fade: false,
    cssEase: 'ease-in-out',
    onInit: function(slick){
      // 초기화 시 전체 슬라이드 개수 표시
      var totalSlides = slick.slideCount;
      $('#total-slides').text(totalSlides);
    },
    onAfterChange: function(slick, currentSlide){
      // 슬라이드 변경 시 현재 슬라이드 번호 업데이트
      $('#current-slide').text(currentSlide + 1);
    }
  });

  // 이전 버튼
  $('.prev').click(function(e){
    e.preventDefault();
    slider.slick('slickPrev');
    return false;
  });

  // 다음 버튼
  $('.next').click(function(e){
    e.preventDefault();
    slider.slick('slickNext');
    return false;
  });

  // 일시정지/재생 버튼
  var isPaused = false;
  $('.pause').click(function(e){
    e.preventDefault();
    if(!isPaused){
      slider.slick('slickPause');
      $(this).addClass('on');
      isPaused = true;
    } else {
      slider.slick('slickPlay');
      $(this).removeClass('on');
      isPaused = false;
    }
    return false;
  });
});
